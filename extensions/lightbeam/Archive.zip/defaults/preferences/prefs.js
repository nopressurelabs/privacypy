pref("extensions.jid1-F9UJ2thwoAm5gQ@jetpack.contributeData", false);
pref("extensions.jid1-F9UJ2thwoAm5gQ@jetpack.defaultVisualization", "graph");
pref("extensions.jid1-F9UJ2thwoAm5gQ@jetpack.defaultFilter", "daily");
